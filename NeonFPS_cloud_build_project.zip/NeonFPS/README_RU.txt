NEON FPS — Android cloud build

Project target:
- Geode: v1.9.0
- Geometry Dash Android: 2.2.143
- ABI: Android64 (arm64-v8a)

This is source code, not a prebuilt .geode file. The included GitHub Actions
workflow attempts to compile it in the cloud.

Phone-only GitHub steps:
1. Create/sign in to a GitHub account.
2. Create a repository named neon-fps-android (public or private).
3. Upload this ZIP file to the repository root as NeonFPS_source_project.zip.
4. In GitHub, choose Add file -> Create new file.
5. Name the file exactly: .github/workflows/build.yml
6. Paste the contents of the separate build.yml file supplied with this project.
7. Commit the new file. The Actions workflow starts automatically on push.
8. Open the Actions tab, open the latest Build Neon FPS run.
9. If successful, download the NeonFPS-Android64 artifact. Unzip it to get the .geode file.

Important:
- This workflow is an attempted build, not a guarantee of compatibility.
- The old Geode 1.9.0 SDK may not be available in the current build action.
- The code has not been compiled or tested in-game.
- If the run fails, share the error log (not account passwords or private tokens).
