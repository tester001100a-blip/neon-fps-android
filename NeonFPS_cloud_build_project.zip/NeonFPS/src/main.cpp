\
    #include <Geode/Geode.hpp>
    #include <Geode/modify/PlayLayer.hpp>

    using namespace geode::prelude;

    // Small gameplay-only FPS overlay. It counts rendered update calls over
    // short windows, avoiding any dependency on platform-specific APIs.
    class NeonFPSLabel final : public CCNode {
    protected:
        CCLabelBMFont* m_label = nullptr;
        float m_elapsed = 0.f;
        unsigned int m_frames = 0;

        bool init() {
            if (!CCNode::init()) return false;

            auto winSize = CCDirector::sharedDirector()->getWinSize();

            m_label = CCLabelBMFont::create("FPS: --", "bigFont.fnt");
            if (!m_label) return false;

            m_label->setAnchorPoint({0.f, 1.f});
            m_label->setScale(0.42f);
            m_label->setPosition({8.f, winSize.height - 8.f});
            m_label->setColor({0, 255, 150});
            this->addChild(m_label);

            this->scheduleUpdate();
            return true;
        }

        void update(float dt) override {
            CCNode::update(dt);

            ++m_frames;
            m_elapsed += dt;

            if (m_elapsed >= 0.5f) {
                float fps = m_elapsed > 0.f
                    ? static_cast<float>(m_frames) / m_elapsed
                    : 0.f;

                auto value = static_cast<int>(fps + 0.5f);
                m_label->setString(("FPS: " + std::to_string(value)).c_str());

                m_elapsed = 0.f;
                m_frames = 0;
            }
        }

    public:
        static NeonFPSLabel* create() {
            auto ret = new NeonFPSLabel();
            if (ret && ret->init()) {
                ret->autorelease();
                return ret;
            }
            CC_SAFE_DELETE(ret);
            return nullptr;
        }
    };

    class $modify(NeonFPSPlayLayer, PlayLayer) {
        bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
            if (!PlayLayer::init(level, useReplay, dontCreateObjects))
                return false;

            if (auto overlay = NeonFPSLabel::create()) {
                this->addChild(overlay, 9999);
            }
            return true;
        }
    };
